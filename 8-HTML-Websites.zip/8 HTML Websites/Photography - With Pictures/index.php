<?php 
error_reporting(E_ALL ^ E_NOTICE); // hide all basic notices from PHP

//If the form is submitted
if(isset($_POST['submitted'])) {
	
	// require a name from user
	if(trim($_POST['contactName']) === '') {
		$nameError =  'Forgot your name!'; 
		$hasError = true;
	} else {
		$name = trim($_POST['contactName']);
	}
	
	// need valid email
	if(trim($_POST['email']) === '')  {
		$emailError = 'Forgot your e-mail address.';
		$hasError = true;
	} else if (!preg_match("/^[[:alnum:]][a-z0-9_.-]*@[a-z0-9.-]+\.[a-z]{2,4}$/i", trim($_POST['email']))) {
		$emailError = 'Invalid email address!';
		$hasError = true;
	} else {
		$email = trim($_POST['email']);
	}
		
	// we need at least some content
	if(trim($_POST['comments']) === '') {
		$commentError = 'You your message!';
		$hasError = true;
	} else {
		if(function_exists('stripslashes')) {
			$comments = stripslashes(trim($_POST['comments']));
		} else {
			$comments = trim($_POST['comments']);
		}
	}
		
	// upon no failure errors let's email now!
	if(!isset($hasError)) {
		
		$emailTo = 'support@w3newbie.com'; // ADD YOUR EMAIL ADDRESS HERE FOR CONTACT FORM!
		$subject = 'Submitted message from '.$name; // ADD YOUR EMAIL SUBJECT LINE HERE FOR CONTACT FORM!
		$sendCopy = trim($_POST['sendCopy']);
		$body = "Name: $name \n\nEmail: $email \n\nComments: $comments";
		$headers = 'From: ' .' <'.$emailTo.'>' . "\r\n" . 'Reply-To: ' . $email;

		mail($emailTo, $subject, $body, $headers);
        
        // set our boolean completion value to TRUE
		$emailSent = true;
	}
}
?>
<!DOCTYPE html> 
<html lang="en">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Photography</title>
	<link rel="stylesheet" type="text/css" href="style.css" />	
	<link href="css/font-awesome.min.css" rel="stylesheet"/>
	<link rel="shortcut icon" type="image/png" href="img/camera-icon.png"/>
	<link href="css/jquery.bxslider.css" rel="stylesheet" />
  	<link rel="stylesheet" href="css/lightbox.min.css">
</head>
<body>
	<section class="intro">
		<nav>
			<a href="#" id="menu-icon"></a>
			<ul>
				<li><a href="#about">About Me</a></li>
				<li><a href="#port">Portfolio</a></li>
				<li><a href="#serv">Services</a></li>
				<li><a href="#contact">Contact Me</a></li>
			</ul>
		</nav>
		<div class="inner">
			<div class="content">
				<h1>Photography</h1>
				<p>my pictures.</p>
			</div>
		</div>
	</section>
	<a name="about">
<div class="clearfix"></div>
		<section class="left-col">
			<h2>About Me</h2>
			<p style="text-indent: 6%;">I am so grateful for each and every experience that life has had to offer me and I’m honestly humbled to be part of each and every wedding. I am right there documenting this amazing moment…it is crazy bananas when you really stop and think about it! While I take this responsibility of very seriously I do strive to create a comfortable, relaxed atmosphere so you are free to be you.</p>
		</section>
		<section class="sidebar">
			<img src="img/model.jpeg">
		</section>
<div class="clearfix"></div>
		<a name="port">
		<h2>My Portfolio</h2>
		<div class="clearfix"></div>
		<section class="one-third-port">
			<a href="https://static.pexels.com/photos/246368/pexels-photo-246368.jpeg" class="example-image-link" data-lightbox="example-set" data-title="Photo Description."><img src="img/photography-1.png" alt="" title=""></a>
		</section>
		<section class="one-third-port">
			<a href="https://static.pexels.com/photos/90368/pexels-photo-90368.jpeg" class="example-image-link" data-lightbox="example-set" data-title="Photo Description."><img src="img/photography-2.png" alt="" title=""></a>
		</section>
		<section class="one-third-port">
			<a href="https://static.pexels.com/photos/241555/pexels-photo-241555.jpeg" class="example-image-link" data-lightbox="example-set" data-title="Photo Description."><img src="img/photography-3.png" alt="" title=""></a>
		</section>
		<section class="one-third-port">
			<a href="https://static.pexels.com/photos/91988/pexels-photo-91988.jpeg" class="example-image-link" data-lightbox="example-set" data-title="Photo Description."><img src="img/photography-4.png" alt="" title=""></a>
		</section>
		<section class="one-third-port">
			<a href="https://static.pexels.com/photos/65121/pexels-photo-65121.jpeg" class="example-image-link" data-lightbox="example-set" data-title="Photo Description."><img src="img/photography-5.png" alt="" title=""></a>
		</section>
		<section class="one-third-port">
			<a href="https://static.pexels.com/photos/47426/pexels-photo-47426.jpeg" class="example-image-link" data-lightbox="example-set" data-title="Photo Description."><img src="img/photography-6.png" alt="" title=""></a>
		</section>
  <script src="js/lightbox-plus-jquery.min.js"></script>
<div class="clearfix"></div>
		<a name="serv">
		<section class="left-col">
		<h2>My Services</h2>
			<p style="text-indent: 6%;">Since I started to offer my photography services, I've become a respected leader in the art of photographs. I believe that the quality of our work has only one judge – our customers.  That’s why we offer a client satisfaction guarantee for every project.  I'm not happy if my clients aren’t happy!  </p>
		</section>
		<section class="sidebar">
			<section class="contact">
				<p>Weddings <br class="break"> Portrait <br class="break"> Engagements <br class="break"> Social Events  <br class="break">  Artistic Modeling <br class="break"> School Photos <br class="break">  Family Portraits</p>
			</section>
		</section>
<div class="clearfix"></div>
<!--- Start Parallax Section -->
<section class="parallax">
	<div class="parallax-inner">
	</div>
</section>
<!--- End Parallax Section -->
<div class="clearfix"></div>
	<a name="contact">
<div class="clearfix"></div>
		<h2>Contact Me</h2>
		<section class="contact">
			<p>My Name <br class="break"> <a href="mailto:me@photography.com">me@photography.com</a>  <br class="break">  1-800-888-8888</p>
			<p>1000 Street Road  <br class="break">  My City  <br class="break">  My State  <br class="break">  19000</p>
		</section>
<!-- Start Contact Form -->
	<section class="contact">
	<div id="contact-area">
	<div id="contact" class="section">
		<div class="container content">
	        <?php if(isset($emailSent) && $emailSent == true) { ?>
                <p class="info">Your email was sent. Huzzah!</p>
            <?php } else { ?>		
				</div>	
				<div id="contact-form">
					<?php if(isset($hasError) || isset($captchaError) ) { ?>
                        <p class="alert">Error submitting the form</p>
                    <?php } ?>
				
					<form id="contact-us" action="index.php" method="post">
						<div class="formblock">
							<label class="screen-reader-text">Name:</label>
							<input type="text" name="contactName" id="contactName" value="<?php if(isset($_POST['contactName'])) echo $_POST['contactName'];?>" class="txt requiredField" placeholder="Name:" />
							<?php if($nameError != '') { ?>
								<br /><span class="error"><?php echo $nameError;?></span> 
							<?php } ?>
						</div>
                        <div class="clearfix"></div>
						<div class="formblock">
							<label class="screen-reader-text">Email:</label>
							<input type="text" name="email" id="email" value="<?php if(isset($_POST['email']))  echo $_POST['email'];?>" class="txt requiredField email" placeholder="Email:" />
							<?php if($emailError != '') { ?>
								<br /><span class="error"><?php echo $emailError;?></span>
							<?php } ?>
						</div>
                        <div class="clearfix"></div>
						<div class="formblock">
							<label class="screen-reader-text">Message:</label>
							 <textarea name="comments" id="commentsText" class="txtarea requiredField" placeholder="Message:"><?php if(isset($_POST['comments'])) { if(function_exists('stripslashes')) { echo stripslashes($_POST['comments']); } else { echo $_POST['comments']; } } ?></textarea>
							<?php if($commentError != '') { ?>
								<br /><span class="error"><?php echo $commentError;?></span> 
							<?php } ?>
						</div>
                      <div class="clearfix"></div>  
							<button name="submit" type="submit" class="subbutton">Submit</button>
							<input type="hidden" name="submitted" id="submitted" value="true" />
					</form>			
			<?php } ?>
		</div>
    </div>
<script type="text/javascript">
	<!--//--><![CDATA[//><!--
	$(document).ready(function() {
		$('form#contact-us').submit(function() {
			$('form#contact-us .error').remove();
			var hasError = false;
			$('.requiredField').each(function() {
				if($.trim($(this).val()) == '') {
					var labelText = $(this).prev('label').text();
					$(this).parent().append('<span class="error">Forgot your '+labelText+'!</span>');
					$(this).addClass('inputError');
					hasError = true;
				} else if($(this).hasClass('email')) {
					var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
					if(!emailReg.test($.trim($(this).val()))) {
						var labelText = $(this).prev('label').text();
						$(this).parent().append('<span class="error">Sorry! Invalid '+labelText+'!</span>');
						$(this).addClass('inputError');
						hasError = true;
					}
				}
			});
			if(!hasError) {
				var formInput = $(this).serialize();
				$.post($(this).attr('action'),formInput, function(data){
					$('form#contact-us').slideUp("fast", function() {				   
						$(this).before('<p class="tick"><h3>Thanks! Your email has been delivered!</h3></p>');
					});
				});
			}
			
			return false;	
		});
	});
	//-->!]]>
</script>
	</div>
</section>
<!-- End Contact Form -->
<div class="clearfix"></div>
<!--- Start Social -->
	<footer>
		<ul class="social">
			<li><a href="https://www.facebook.com/w3newbie" target="_blank"><i class="fa fa-facebook"></i></a></li>
			<li><a href="https://plus.google.com/+DrewRyan_w3/posts" target="_blank"><i class="fa fa-google-plus"></i></a></li>
			<li><a href="https://twitter.com/DrewOnCue" target="_blank"><i class="fa fa-twitter"></i></a></li>
			<li><a href="https://youtube.com/user/DrewOnCue" target="_blank"><i class="fa fa-youtube"></i></a></li>
			<li><a href="https://www.instagram.com/drew_ryan_/" target="_blank"><i class="fa fa-instagram"></i></a></li>
		</ul>
	</footer>
	<footer class="second">
		<p>&copy; Photography.</p>
	</footer>
<!--- End Footer -->
<!--- Top Scroll Start -->
	<a href="#0" class="cd-top">Top</a>
		<script src="js/top.js"></script> <!-- Gem jQuery -->
		<script src="js/modernizr.js"></script>
<!--- Top Scroll End -->
</body>
</html>