<?php 
error_reporting(E_ALL ^ E_NOTICE); // hide all basic notices from PHP

//If the form is submitted
if(isset($_POST['submitted'])) {
	
	// require a name from user
	if(trim($_POST['contactName']) === '') {
		$nameError =  'Forgot your name!'; 
		$hasError = true;
	} else {
		$name = trim($_POST['contactName']);
	}
	
	// need valid email
	if(trim($_POST['email']) === '')  {
		$emailError = 'Forgot your e-mail address.';
		$hasError = true;
	} else if (!preg_match("/^[[:alnum:]][a-z0-9_.-]*@[a-z0-9.-]+\.[a-z]{2,4}$/i", trim($_POST['email']))) {
		$emailError = 'Invalid email address!';
		$hasError = true;
	} else {
		$email = trim($_POST['email']);
	}
		
	// we need at least some content
	if(trim($_POST['comments']) === '') {
		$commentError = 'You your message!';
		$hasError = true;
	} else {
		if(function_exists('stripslashes')) {
			$comments = stripslashes(trim($_POST['comments']));
		} else {
			$comments = trim($_POST['comments']);
		}
	}
		
	// upon no failure errors let's email now!
	if(!isset($hasError)) {
		
		$emailTo = 'youremail@email.com'; // ADD YOUR EMAIL ADDRESS HERE FOR CONTACT FORM!
		$subject = 'Submitted message from '.$name; // ADD YOUR EMAIL SUBJECT LINE HERE FOR CONTACT FORM!
		$sendCopy = trim($_POST['sendCopy']);
		$body = "Name: $name \n\nEmail: $email \n\nComments: $comments";
		$headers = 'From: ' .' <'.$emailTo.'>' . "\r\n" . 'Reply-To: ' . $email;

		mail($emailTo, $subject, $body, $headers);
        
        // set our boolean completion value to TRUE
		$emailSent = true;
	}
}
?>
<!DOCTYPE html>
<html lang="en"> 
<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Business - Connect With Us</title>
		<link href="css/jquery.bxslider.css" rel="stylesheet" />
		<link href="style.css" rel="stylesheet">
		<link href="css/font-awesome.min.css" rel="stylesheet"/>
		<link rel="shortcut icon" type="image/png" href="img/biz_favicon.png"/>
		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
		<meta name="description" content="Don't waste your time looking for solutions that may not give you the results you need.  Let Business provide services to you so you can flourish.">
</head>

<body>
<!--- Start Wrapper -->
	<div id="wrapper">
<!--- Start Header -->
		<header>
			<div id="callout">
				<h2>&#9742; 888.828.8008</h2>
				<p>123 West Avenue, New York, NY 10001</p>
			</div>
			<div id="logo">
				<a href="index.html"><img src="img/biz_logo.png" title="Business"/></a>
			</div>
		</header>
<!--- End Header -->
	<div class="clearfix"></div>
<!--- Sart Banner Wrapper -->
		<div id="banner-wrapper">
<!--- Start Navigation -->
		<script src="js/jquery-1.11.2.min.js"></script>
		<script src="js/main.js"></script> <!--- For Navigation -->
		<div class="nav-wrap">
			<div class="menu-toggle-wrap">
				<span class="toggle-menu"><i class="fa fa-navicon"></i></span>
			</div>
			<nav class="navigation">
				<div class='nav' nav-menu-style="yoga">
					<ul class="nav-menu">
						<li><a href="index.html">Home</a></li>
						<li><a href="about-us.html">About Us</a></li>
						<li><a href="services.html">Services</a>
							<ul>
								<li><a href="#">Service 1</a></li>
								<li><a href="#">Service 2</a>
									<ul>
										<li><a href="#">Service 3</a></li>
									</ul>
								</li>
							</ul>
						</li>
						<li><a href="testimonials.html">Testimonials</a></li> 
						<li class="active"><a href="contact.php">Contact</a></li>
					</ul>
				</div>
			</nav>
		</div>
<!--- End Navigation -->
<!--- Start Bread Crumbs -->
			<div id="bread-crumbs">
				<h3>Contact Us</h3>
			</div>
		</div>
<!--- End Bread Crumbs -->
<!--- End Banner Wrapper -->
<!--- Start Banner Image -->
		<div class="banner-img">
			<img src="img/biz_chart.png" title="Image Description"/>
		</div>
	<div class="clearfix"></div>
<!--- End Banner Image -->
	<div class="clearfix"></div>	
<!--- Start Contact Info -->
		<section class="one-third">
			<h2>Our Contact info:</h2>
				<br>
			<h3>123 West Avenue<br>New York, NY 10001</h3>
				<br>
			<h3 class"phone"><strong>Phone :</strong>888-828-8008</h3>
				<br>
			<h3><strong>Email :</strong> info@business.com</h3>
				<br>
			<p>Thank you for visiting our website, we'd be happy to hear from you and start a long lasting relationship if your a new comer!</p>
		</section>
<!-- End Contact Info -->
<!-- Start Contact Form -->
	<section class="two-third" class="contact">
	<div id="contact-area">
	<div id="contact" class="section">
		<div class="container content">
	        <?php if(isset($emailSent) && $emailSent == true) { ?>
                <p class="info">Your email was sent. Huzzah!</p>
            <?php } else { ?>		
				</div>	
				<div id="contact-form">
					<?php if(isset($hasError) || isset($captchaError) ) { ?>
                        <p class="alert">Error submitting the form</p>
                    <?php } ?>
				
					<form id="contact-us" action="contact.php" method="post">
						<div class="formblock">
							<label class="screen-reader-text">Name</label>
							<input type="text" name="contactName" id="contactName" value="<?php if(isset($_POST['contactName'])) echo $_POST['contactName'];?>" class="txt requiredField" placeholder="Name:" />
							<?php if($nameError != '') { ?>
								<br /><span class="error"><?php echo $nameError;?></span> 
							<?php } ?>
						</div>
                        <div class="clearfix"></div>
						<div class="formblock">
							<label class="screen-reader-text">Email</label>
							<input type="text" name="email" id="email" value="<?php if(isset($_POST['email']))  echo $_POST['email'];?>" class="txt requiredField email" placeholder="Email:" />
							<?php if($emailError != '') { ?>
								<br /><span class="error"><?php echo $emailError;?></span>
							<?php } ?>
						</div>
                        <div class="clearfix"></div>
						<div class="formblock">
							<label class="screen-reader-text">Message</label>
							 <textarea name="comments" id="commentsText" class="txtarea requiredField" placeholder="Message:"><?php if(isset($_POST['comments'])) { if(function_exists('stripslashes')) { echo stripslashes($_POST['comments']); } else { echo $_POST['comments']; } } ?></textarea>
							<?php if($commentError != '') { ?>
								<br /><span class="error"><?php echo $commentError;?></span> 
							<?php } ?>
						</div>
                      <div class="clearfix"></div>  
							<button name="submit" type="submit" class="subbutton">Submit</button>
							<input type="hidden" name="submitted" id="submitted" value="true" />
					</form>			
			<?php } ?>
		</div>
    </div>
<script type="text/javascript">
	<!--//--><![CDATA[//><!--
	$(document).ready(function() {
		$('form#contact-us').submit(function() {
			$('form#contact-us .error').remove();
			var hasError = false;
			$('.requiredField').each(function() {
				if($.trim($(this).val()) == '') {
					var labelText = $(this).prev('label').text();
					$(this).parent().append('<span class="error">Forgot your '+labelText+'!</span>');
					$(this).addClass('inputError');
					hasError = true;
				} else if($(this).hasClass('email')) {
					var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
					if(!emailReg.test($.trim($(this).val()))) {
						var labelText = $(this).prev('label').text();
						$(this).parent().append('<span class="error">Sorry! Invalid '+labelText+'!</span>');
						$(this).addClass('inputError');
						hasError = true;
					}
				}
			});
			if(!hasError) {
				var formInput = $(this).serialize();
				$.post($(this).attr('action'),formInput, function(data){
					$('form#contact-us').slideUp("fast", function() {				   
						$(this).before('<p class="tick"><h3>Thanks! Your email has been delivered!</h3></p>');
					});
				});
			}
			
			return false;	
		});
	});
	//-->!]]>
</script>
			</div>
		</section>
<!-- End Contact Form -->
	<div class="clearfix"></div>				
<!--- Start Footer -->
		<footer>
			<section class="one-third">
				<h3>Contact Us</h3>
				</br>
				<p class="footercontact">Business<br>
				<b class="phone">888-828-8008</b><br></br>
				123 West Avenue<br>
				New York, NY 10001<br>
				info@business.com</p>
				</br>
				<ul class="social">
					<li><a href="https://www.facebook.com/w3newbie" target="_blank"title="Like Business on Facebook"><i class="fa fa-facebook"></i></a></li>
					<li><a href="https://plus.google.com/+DrewRyan_w3/posts" target="_blank"title="Follow Drew on Google Plus"><i class="fa fa-google-plus"></i></a></li>
					<li><a href="https://twitter.com/DrewOnCue" target="_blank"title="Follow Drew on Twitter"><i class="fa fa-twitter"></i></a></li>
					<li><a href="https://youtube.com/user/DrewOnCue" target="_blank"title="Subscribe to Drew on YouTube"><i class="fa fa-youtube"></i></a></li>
				</ul>
			</section>
			<section class="one-third">
				<h3>Our Location</h3>
					</br>
				<div class="google-maps">			
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d48348.20310746617!2d-73.9787368622817!3d40.76724383438692!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew+York%2C+NY!5e0!3m2!1sen!2sus!4v1438046993592"></iframe>
				</div>
			</section>
			<section class="one-third">
				<h3>Our Philosophy</h3>
					</br>
				<p>We at Business would like to solve as many problems as possible to make the world a better, more relaxing place for our customers and clients based on their needs.  Our goal is to have their systems run seamlessly day to day and without any effort.</p>
			</section>
		</footer>
<!--- End Footer -->
		<p>&copy; Business, 2016.</p>
	</div>
<!--- End Wrapper -->
<!--- Top Scroll Start -->
	<a href="#0" class="cd-top">Top</a>
		<script src="js/top.js"></script> <!-- Gem jQuery -->
		<script src="js/modernizr.js"></script>
<!--- Top Scroll End -->
</body>
</html>