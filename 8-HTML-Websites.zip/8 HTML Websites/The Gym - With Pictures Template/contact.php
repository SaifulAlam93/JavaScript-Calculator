<?php 
error_reporting(E_ALL ^ E_NOTICE); // hide all basic notices from PHP

//If the form is submitted
if(isset($_POST['submitted'])) {
	
	// require a name from user
	if(trim($_POST['contactName']) === '') {
		$nameError =  'Forgot your name!'; 
		$hasError = true;
	} else {
		$name = trim($_POST['contactName']);
	}
	
	// need valid email
	if(trim($_POST['email']) === '')  {
		$emailError = 'Forgot your e-mail address.';
		$hasError = true;
	} else if (!preg_match("/^[[:alnum:]][a-z0-9_.-]*@[a-z0-9.-]+\.[a-z]{2,4}$/i", trim($_POST['email']))) {
		$emailError = 'Invalid email address!';
		$hasError = true;
	} else {
		$email = trim($_POST['email']);
	}
		
	// we need at least some content
	if(trim($_POST['comments']) === '') {
		$commentError = 'You your message!';
		$hasError = true;
	} else {
		if(function_exists('stripslashes')) {
			$comments = stripslashes(trim($_POST['comments']));
		} else {
			$comments = trim($_POST['comments']);
		}
	}
		
	// upon no failure errors let's email now!
	if(!isset($hasError)) {
		
		$emailTo = 'youremail@email.com'; // ADD YOUR EMAIL ADDRESS HERE FOR CONTACT FORM!
		$subject = 'Submitted message from '.$name; // ADD YOUR EMAIL SUBJECT LINE HERE FOR CONTACT FORM!
		$sendCopy = trim($_POST['sendCopy']);
		$body = "Name: $name \n\nEmail: $email \n\nComments: $comments";
		$headers = 'From: ' .' <'.$emailTo.'>' . "\r\n" . 'Reply-To: ' . $email;

		mail($emailTo, $subject, $body, $headers);
        
        // set our boolean completion value to TRUE
		$emailSent = true;
	}
}
?>
<!DOCTYPE html> 
<html lang="en">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>The Gym - Personal Training</title>
	<link href="css/jquery.bxslider.css" rel="stylesheet" />
	<link rel="stylesheet" type="text/css" href="style.css" />	
	<link href="css/font-awesome.min.css" rel="stylesheet"/>
	<link rel="shortcut icon" type="image/png" href="img/gym_favicon.png"/>
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
	<meta name="description" content="">
	<script src="js/jquery-1.11.2.min.js"></script>
</head>
<body>
	<header>
		<div id="header-inner">
		<a href="index.html" id="logo" title=""></a>
		<nav>
			<a href="#" id="menu-icon"></a>
			<ul>
				<li><a href="index.html">Home</a></li>
				<li><a href="about.html">About</a></li>
				<li><a href="facility.html">Facility</a></li>
				<li><a href="pricing.html">Pricing</a></li>
				<li><a href="contact.php" class="current">Contact</a></li>
			</ul>
		</nav>
		</div>
	</header>
<!--- Start Bread Crumbs -->
	<div id="bread-banner">
		<div id="bread-banner-inner">
			<h3>Contact Us</h3>
			<h5 class="bread-here">You are here: HOME / CONTACT</h5>
			<h5 class="bread-phone">555-525-5005</h5>
		</div>
	</div>
<!--- End Bread Crumbs -->
	<div class="clearfix"></div>
		<div id="inner-wrapper">
			<h3 class="text-welcome">We'd be happy to hear from you</h3>
			<div class="line-rule"></div>
<!-- Start Contact Form -->
	<section class="two-third" class="contact">
	<div id="contact-area">
	<div id="contact" class="section">
		<div class="container content">
	        <?php if(isset($emailSent) && $emailSent == true) { ?>
                <p class="info">Your email was sent. Huzzah!</p>
            <?php } else { ?>		
				</div>	
				<div id="contact-form">
					<?php if(isset($hasError) || isset($captchaError) ) { ?>
                        <p class="alert">Error submitting the form</p>
                    <?php } ?>
				
					<form id="contact-us" action="contact.php" method="post">
						<div class="formblock">
							<label class="screen-reader-text"><h5>Name</h5></label>
							<input type="text" name="contactName" id="contactName" value="<?php if(isset($_POST['contactName'])) echo $_POST['contactName'];?>" class="txt requiredField" placeholder="Name:" />
							<?php if($nameError != '') { ?>
								<br /><span class="error"><?php echo $nameError;?></span> 
							<?php } ?>
						</div>
                        <div class="clearfix"></div>
						<div class="formblock">
							<label class="screen-reader-text"><h5>Email</h5></label>
							<input type="text" name="email" id="email" value="<?php if(isset($_POST['email']))  echo $_POST['email'];?>" class="txt requiredField email" placeholder="Email:" />
							<?php if($emailError != '') { ?>
								<br /><span class="error"><?php echo $emailError;?></span>
							<?php } ?>
						</div>
                        <div class="clearfix"></div>
						<div class="formblock">
							<label class="screen-reader-text"><h5>Message</h5></label>
							 <textarea name="comments" id="commentsText" class="txtarea requiredField" placeholder="Message:"><?php if(isset($_POST['comments'])) { if(function_exists('stripslashes')) { echo stripslashes($_POST['comments']); } else { echo $_POST['comments']; } } ?></textarea>
							<?php if($commentError != '') { ?>
								<br /><span class="error"><?php echo $commentError;?></span> 
							<?php } ?>
						</div>
                      <div class="clearfix"></div>  
							<button name="submit" type="submit" class="subbutton"><h5>Submit</h5></button>
							<input type="hidden" name="submitted" id="submitted" value="true" />
					</form>			
			<?php } ?>
		</div>
    </div>
<script type="text/javascript">
	<!--//--><![CDATA[//><!--
	$(document).ready(function() {
		$('form#contact-us').submit(function() {
			$('form#contact-us .error').remove();
			var hasError = false;
			$('.requiredField').each(function() {
				if($.trim($(this).val()) == '') {
					var labelText = $(this).prev('label').text();
					$(this).parent().append('<span class="error">Forgot your '+labelText+'!</span>');
					$(this).addClass('inputError');
					hasError = true;
				} else if($(this).hasClass('email')) {
					var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
					if(!emailReg.test($.trim($(this).val()))) {
						var labelText = $(this).prev('label').text();
						$(this).parent().append('<span class="error">Sorry! Invalid '+labelText+'!</span>');
						$(this).addClass('inputError');
						hasError = true;
					}
				}
			});
			if(!hasError) {
				var formInput = $(this).serialize();
				$.post($(this).attr('action'),formInput, function(data){
					$('form#contact-us').slideUp("fast", function() {				   
						$(this).before('<p class="tick"><h3>Thanks! Your email has been delivered!</h3></p>');
					});
				});
			}
			
			return false;	
		});
	});
	//-->!]]>
</script>
			</div>
		</section>
<!-- End Contact Form -->
	</div> 
<!--- End Inner Wrapper -->
	<div class="clearfix"></div>
<!--- Start Footer -->
		<footer>
		<div id="footer-inner">
			<section class="one-third" id="footer-third">
				<h3>Contact</h3>
				<p class="footercontact">The Gym<br>
				<b class="phone">555-525-5005</b><br><br>
				500 Washington Road<br>
				Seattle, WA 98101<br></p>
		</section>
		<section class="one-third" id="footer-third">
			<h3>Social</h3>
			<br>
				<ul class="social">
					<li><a href="https://www.facebook.com/w3newbie" target="_blank"title=""><i class="fa fa-facebook" id="facebook"></i></a></li>
					<li><a href="https://plus.google.com/+DrewRyan_w3/posts" target="_blank"title=""><i class="fa fa-google-plus" id="google-plus"></i></a></li>
					<li><a href="https://twitter.com/DrewOnCue" target="_blank"title=""><i class="fa fa-twitter" id="twitter"></i></a></li>
					<li><a href="https://youtube.com/user/DrewOnCue" target="_blank"title=""><i class="fa fa-youtube" id="youtube"></i></a></li>
				</ul>
		</section>
		<section class="one-third" id="footer-third-last">
				<h3>Pages</h3>
				<br>
				<h5><a href="index.html">home</a> - <a href="about.html">about</a> - <a href="facility.html">facility</a> - <a href="pricing.html">pricing</a> - <a href="contact.php">contact</a></h5>
		</section>
	</div>
	</footer>
	<footer class="second">
		<p>&copy; The Gym, 2017.</p>
	</footer>
<!--- End Footer -->
<!--- Top Scroll Start -->
	<a href="#0" class="cd-top">Top</a>
		<script src="js/top.js"></script> <!-- Gem jQuery -->
		<script src="js/modernizr.js"></script>
<!--- Top Scroll End --> 
</body>
</html>
